<template>

</template>

<script>
    export default {
        name: 'c_hot_box'
    }
</script>

<style scoped>

</style>
