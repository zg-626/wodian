<template>
    <div class="mobile-config pro">

        <div  v-for="(item,key) in rCom" :key="key">
            <component :is="item.components.name" :configObj="configObj" ref="childData" :configNme="item.configNme" :key="key" @getConfig="getConfig" :index="activeIndex" :num="item.num"></component>
        </div>
        <rightBtn :activeIndex="activeIndex" :configObj="configObj"></rightBtn>
    </div>
</template>

<script>
// +----------------------------------------------------------------------
// | CRMEB [ CRMEB赋能开发者，助力企业发展 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2024 https://www.crmeb.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
// +----------------------------------------------------------------------
// | Author: CRMEB Team <admin@crmeb.com>
// +----------------------------------------------------------------------
import toolCom from '@/components/mobileConfigRight/index.js'
import rightBtn from '@/components/rightBtn/index.vue';
export default {
    name: 'c_home_pink',
    cname: '拼团',
    componentsName: 'home_pink',
    props: {
        activeIndex: {
            type: null
        },
        num: {
            type: null
        },
        index: {
            type: null
        }
    },
    components: {
        ...toolCom,
        rightBtn
    },
    data () {
        return {
            configObj: {},
            tabVal: 0,
            rCom: [
                {
                    components: toolCom.c_set_up,
                    configNme: 'setUp'
                }
            ]
        }
    },
    watch: {
        num (nVal) {
            let value = JSON.parse(JSON.stringify(this.$store.state.mobildConfig.defaultArray[nVal]))
            this.configObj = value;
        },
        configObj: {
            handler (nVal, oVal) {
                this.$store.commit('mobildConfig/UPDATEARR', { num: this.num, val: nVal });
            },
            deep: true
        },
        'configObj.setUp.tabVal': {
            handler (nVal, oVal) {   
                var arr = [this.rCom[0]]
                let tempArr = [
                    {
                        components: toolCom.c_is_show,
                        configNme: 'priceShow'
                    },
                    {
                        components: toolCom.c_is_show,
                        configNme: 'bntShow'
                    },
                    {
                        components: toolCom.c_is_show,
                        configNme: 'titleShow'
                    },
                    {
                        components: toolCom.c_is_show,
                        configNme: 'pinkShow'
                    },
                ]
                if (nVal == 0) {
                    if(this.tabVal == 2){
                       tempArr = [
                            {
                                components: toolCom.c_is_show,
                                configNme: 'priceShow'
                            },
                            {
                                components: toolCom.c_is_show,
                                configNme: 'bntShow'
                            },
                            {
                                components: toolCom.c_is_show,
                                configNme: 'titleShow'
                            },
                        ] 
                    }  
                    this.rCom = arr.concat(tempArr)
                } else {
                    let tempArr = [
                        {
                            components: toolCom.c_tab,
                            configNme: 'tabConfig'
                        },
                        {
                            components: toolCom.c_bg_color,
                            configNme: 'txtColor'
                        },
                        {
                            components: toolCom.c_bg_color,
                            configNme: 'themeColor'
                        },
                        {
                            components: toolCom.c_bg_color,
                            configNme: 'bgColor'
                        },
                        {
                            components: toolCom.c_txt_tab,
                            configNme: 'conStyle'
                        },
                        {
                            components: toolCom.c_txt_tab,
                            configNme: 'bgStyle'
                        },
                        // {
                        //     components: toolCom.c_slider,
                        //     configNme: 'prConfig'
                        // },
                        {
                            components: toolCom.c_slider,
                            configNme: 'mbConfig'
                        }
                    ]
                    this.rCom = arr.concat(tempArr)
                }
            },
            deep: true
        },
        'configObj.tabConfig.tabVal': {
            handler (nVal, oVal) {
                this.tabVal = nVal
            },
            deep: true
        },
    },
   
    mounted () {
        this.$nextTick(() => {
            let value = JSON.parse(JSON.stringify(this.$store.state.mobildConfig.defaultArray[this.num]))
            this.configObj = value;
        })
    },
    methods: {
        getConfig (data) {

        },
    }
}
</script>

<style scoped>

</style>
