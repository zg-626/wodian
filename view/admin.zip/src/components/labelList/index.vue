<template>
    <div class="label-wrapper">
				<div class="list-box">
					<div class="label-box" v-for="(item,index) in labelList" :key="index" v-if="isUser">
					    <div class="title" v-if="item.children">{{item.label_name}}</div>
					    <div class="list" v-if="item.children && item.children.length">
					        <div class="label-item" :class="{on:label.disabled}" v-for="(label,j) in item.children" :key="j" @click="selectLabel(label)">{{label.label_name}}</div>
					    </div>
					</div>
					<div v-if="!isUser">暂无标签</div>
				</div>
        <div class="footer">
            <el-button type="primary" class="btns" @click="subBtn">确定</el-button>
            <el-button type="primary" class="btns" ghost @click="cancel">取消</el-button>
        </div>
    </div>
</template>

<script>
// +----------------------------------------------------------------------
// | CRMEB [ CRMEB赋能开发者，助力企业发展 ]
// +----------------------------------------------------------------------
// | Copyright (c) 2016~2024 https://www.crmeb.com All rights reserved.
// +----------------------------------------------------------------------
// | Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
// +----------------------------------------------------------------------
// | Author: CRMEB Team <admin@crmeb.com>
// +----------------------------------------------------------------------
import { productUserLabel } from '@/api/product'
export default {
    name: "userLabel",
    props:{
        // dataLabel: {
        // 	type: Array,
        // 	default: () => []
        // }
    },
    data(){
        return {
            labelList:[],
            dataLabel:[],
            isUser:false
        }
    },
    mounted() {
    },
    methods:{
        inArray: function(search, array) {
            for (let i in array) {
                if (array[i].id == search) {
                    return true;
                }
            }
            return false;
        },
        // 用户标签
        userLabel(data) {
            this.dataLabel = data;
            productUserLabel()
            .then((res) => {
                res.data.map(el=>{
                    if(el.children){
                        this.isUser = true;
                        el.children.map(label=>{
                        if(this.inArray(label.id, this.dataLabel)){
                            label.disabled = true;
                        }else{
                            label.disabled = false;
                        }
                    })
                }  
            })
            this.labelList = res.data					
            })
            .catch((res) => {
                this.$message.error(res.message);
            });
        },
        selectLabel(label){
            if(label.disabled){
                let index = this.dataLabel.indexOf(this.dataLabel.filter(d=>d.id == label.id)[0]);
                this.dataLabel.splice(index,1);
                label.disabled = false
            }else{
                this.dataLabel.push({'label_name':label.label_name,'id':label.id});
                label.disabled = true
            }
        },
        // 确定
        subBtn(){
            this.$emit('activeData',JSON.parse(JSON.stringify(this.dataLabel)))
        },
        cancel(){
            this.$emit('close')
        }
    }
}
</script>

<style lang="scss" scoped>
.label-wrapper{
    .list{
        display: flex;
        flex-wrap: wrap;
        .label-item{
            margin: 10px 8px 10px 0;
            padding: 3px 8px;
            background: #EEEEEE;
            color: #333333;
            border-radius: 2px;
            cursor: pointer;
            font-size: 12px;
            &.on{
                color: #fff;
                background: var(--prev-color-primary);
            }
                
        }      
    }    
    .footer{
        display: flex;
        justify-content: flex-end;
        margin-top: 40px;
        button{
            margin-left: 10px;
        }          
    }      
}   
.btn{
    width: 60px;
    height: 24px;
}  
.title{
    font-size: 13px;
}   
.list-box{
    overflow-y: auto;
	overflow-x: hidden;
	max-height: 240px;
}
		
</style>
